# Wish Board — исходники + Android-проект

- `android/` — проект Android Studio для установки веб-приложения как Android-приложения.
- `ANDROID_SETUP_RU.md` — пошаговая инструкция по публикации и сборке APK.
- `src/`, `server/`, `migrations/`, `package.json` и остальные файлы — исходный веб-проект.

**Сначала нужно развернуть веб-приложение на HTTPS и подключить постоянную базу данных.** После этого укажите адрес в `android/app/src/main/res/values/strings.xml` и соберите APK через Android Studio. Этот архив содержит исходники и Android-оболочку, но не готовый APK.
