export type Wish = {
  id: string;
  title: string;
  note: string;
  image: string | null;
  done: boolean;
  doneAt: number | null;
  createdAt: number;
};

const DB_NAME = "zhelaniya";
const DB_VERSION = 1;
const STORE = "kv";
const KEY = "wishes";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("indexedDB"));
  });
}

function normalize(value: unknown): Wish | null {
  if (!value || typeof value !== "object") return null;
  const wish = value as Partial<Wish>;
  if (typeof wish.id !== "string" || typeof wish.title !== "string") return null;
  if (typeof wish.createdAt !== "number") return null;
  return {
    id: wish.id,
    title: wish.title,
    note: typeof wish.note === "string" ? wish.note : "",
    image: typeof wish.image === "string" ? wish.image : null,
    done: Boolean(wish.done),
    doneAt: typeof wish.doneAt === "number" ? wish.doneAt : null,
    createdAt: wish.createdAt,
  };
}

export async function loadWishes(): Promise<Wish[]> {
  const db = await openDb();
  try {
    const value = await new Promise<unknown>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const request = tx.objectStore(STORE).get(KEY);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("read"));
    });
    if (!Array.isArray(value)) return [];
    return value.flatMap((item) => {
      const wish = normalize(item);
      return wish ? [wish] : [];
    });
  } finally {
    db.close();
  }
}

export async function persistWishes(wishes: Wish[]): Promise<void> {
  const db = await openDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("write"));
      tx.onabort = () => reject(tx.error ?? new Error("write"));
      tx.objectStore(STORE).put(wishes, KEY);
    });
  } finally {
    db.close();
  }
}

export function storageMessage(error: unknown): string {
  if (
    error instanceof DOMException &&
    (error.name === "QuotaExceededError" || error.name === "NS_ERROR_DOM_QUOTA_REACHED")
  ) {
    return "Место в браузере закончилось. Уберите фото или удалите желание.";
  }
  return "Не удалось сохранить список на этом устройстве.";
}

const MAX_STORED = 850_000;

function draw(bitmap: ImageBitmap, maxEdge: number, quality: number): Promise<string> {
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) return Promise.reject(new Error("Не удалось обработать фото"));
  context.drawImage(bitmap, 0, 0, width, height);
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error("Не удалось сжать фото"));
          return;
        }
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result !== "string") {
            reject(new Error("Не удалось прочитать фото"));
            return;
          }
          resolve(reader.result);
        };
        reader.onerror = () => reject(new Error("Не удалось прочитать фото"));
        reader.readAsDataURL(blob);
      },
      "image/jpeg",
      quality,
    );
  });
}

export async function readPhoto(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Нужна фотография — JPEG, PNG или WebP.");
  }
  if (file.size > 25 * 1024 * 1024) {
    throw new Error("Файл больше 25 МБ.");
  }
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error("Браузер не открыл это фото. Попробуйте JPEG или PNG.");
  }
  try {
    let maxEdge = 1600;
    let quality = 0.84;
    let url = await draw(bitmap, maxEdge, quality);
    for (let attempt = 0; attempt < 3 && url.length > MAX_STORED; attempt += 1) {
      maxEdge = Math.round(maxEdge * 0.75);
      quality = Math.max(0.55, quality - 0.12);
      url = await draw(bitmap, maxEdge, quality);
    }
    return url;
  } finally {
    bitmap.close();
  }
}
