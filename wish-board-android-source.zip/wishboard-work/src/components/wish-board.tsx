import { useCallback, useEffect, useMemo, useRef, useState, type DragEvent, type FormEvent } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { clsx, type ClassValue } from "clsx";
import { ArrowLeft, Check, ImagePlus, Plus, Undo2, X } from "lucide-react";
import { twMerge } from "tailwind-merge";
import {
  loadWishes,
  persistWishes,
  readPhoto,
  storageMessage,
  type Wish,
} from "@/lib/wishes";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Filter = "all" | "open" | "done";

type Mode =
  | { kind: "idle" }
  | { kind: "create" }
  | { kind: "edit"; id: string }
  | { kind: "view"; id: string };

type Draft = {
  title: string;
  note: string;
  image: string | null;
};

const EMPTY_DRAFT: Draft = { title: "", note: "", image: null };

const btnPrimary =
  "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-accent px-5 text-sm font-medium text-accent-ink transition-opacity duration-150 ease-out enabled:hover:opacity-90 enabled:active:opacity-80 disabled:opacity-40";
const btnLine =
  "inline-flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-sheet px-5 text-sm font-medium text-ink transition-colors duration-150 ease-out hover:bg-soft";
const btnGhost =
  "inline-flex h-12 items-center justify-center gap-2 rounded-full px-5 text-sm font-medium text-ink transition-colors duration-150 ease-out hover:bg-soft";

function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function listSummary(wishes: Wish[]): string {
  if (wishes.length === 0) return "Тихий список для себя";
  const open = wishes.filter((wish) => !wish.done).length;
  const done = wishes.length - open;
  const parts: string[] = [];
  if (open > 0) {
    const verb = open % 10 === 1 && open % 100 !== 11 ? "ждёт" : "ждут";
    parts.push(`${open} ещё ${verb}`);
  }
  if (done > 0) {
    const verb = done % 10 === 1 && done % 100 !== 11 ? "сбылось" : "сбылись";
    parts.push(`${done} ${verb}`);
  }
  return parts.join(" · ");
}

function ruDate(timestamp: number): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(timestamp));
}

function monogram(title: string): string {
  const letter = title.trim().charAt(0);
  return letter ? letter.toLocaleUpperCase("ru") : "·";
}

export function WishBoard() {
  const [ready, setReady] = useState(false);
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [mode, setMode] = useState<Mode>({ kind: "idle" });
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [busyPhoto, setBusyPhoto] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const wishesRef = useRef<Wish[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const commit = useCallback((next: Wish[]) => {
    wishesRef.current = next;
    setWishes(next);
    void persistWishes(next)
      .then(() => setSaveError(null))
      .catch((error: unknown) => setSaveError(storageMessage(error)));
  }, []);

  useEffect(() => {
    let live = true;
    loadWishes()
      .then((list) => {
        if (!live) return;
        const pending = wishesRef.current.filter((wish) => !list.some((item) => item.id === wish.id));
        const merged = [...pending, ...list];
        wishesRef.current = merged;
        setWishes(merged);
        setReady(true);
        if (pending.length > 0) void persistWishes(merged);
      })
      .catch(() => {
        if (!live) return;
        setReady(true);
        setSaveError("Хранилище браузера недоступно — список пропадёт, когда закроете вкладку.");
      });
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    setConfirmDelete(false);
    setFormError(null);
    setPhotoError(null);
    setDragging(false);
    if (mode.kind === "create") {
      setDraft(EMPTY_DRAFT);
      return;
    }
    if (mode.kind === "edit") {
      const wish = wishesRef.current.find((item) => item.id === mode.id);
      if (!wish) return;
      setDraft({ title: wish.title, note: wish.note, image: wish.image });
    }
  }, [mode]);

  useEffect(() => {
    if (mode.kind !== "view" && mode.kind !== "edit") return;
    if (!ready) return;
    if (!wishes.some((wish) => wish.id === mode.id)) setMode({ kind: "idle" });
  }, [mode, ready, wishes]);

  const takeFile = useCallback(async (file: File) => {
    setBusyPhoto(true);
    setPhotoError(null);
    try {
      const image = await readPhoto(file);
      setDraft((current) => ({ ...current, image }));
    } catch (error) {
      setPhotoError(error instanceof Error ? error.message : "Не удалось прочитать фото");
    } finally {
      setBusyPhoto(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }, []);

  useEffect(() => {
    if (mode.kind !== "create" && mode.kind !== "edit") return;
    const onPaste = (event: ClipboardEvent) => {
      const file = [...(event.clipboardData?.items ?? [])]
        .find((item) => item.type.startsWith("image/"))
        ?.getAsFile();
      if (!file) return;
      event.preventDefault();
      void takeFile(file);
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [mode.kind, takeFile]);

  const visible = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("ru");
    return wishes
      .filter((wish) => {
        if (filter === "open" && wish.done) return false;
        if (filter === "done" && !wish.done) return false;
        if (!needle) return true;
        return `${wish.title}\n${wish.note}`.toLocaleLowerCase("ru").includes(needle);
      })
      .sort((a, b) => {
        if (filter === "all" && a.done !== b.done) return a.done ? 1 : -1;
        if (filter === "done") return (b.doneAt ?? b.createdAt) - (a.doneAt ?? a.createdAt);
        return b.createdAt - a.createdAt;
      });
  }, [filter, query, wishes]);

  const active =
    mode.kind === "view" || mode.kind === "edit"
      ? (wishes.find((wish) => wish.id === mode.id) ?? null)
      : null;

  function openCreate() {
    setMode({ kind: "create" });
  }

  function requestClose() {
    if (mode.kind === "edit") {
      setMode({ kind: "view", id: mode.id });
      return;
    }
    setMode({ kind: "idle" });
  }

  function saveDraft(event: FormEvent) {
    event.preventDefault();
    const title = draft.title.trim();
    const note = draft.note.trim();
    if (!title) {
      setFormError("Напишите, чего хотите.");
      return;
    }
    if (title.length > 80) {
      setFormError("Название — до 80 символов.");
      return;
    }
    if (note.length > 400) {
      setFormError("Заметка — до 400 символов.");
      return;
    }
    if (mode.kind === "create") {
      const wish: Wish = {
        id: uid(),
        title,
        note,
        image: draft.image,
        done: false,
        doneAt: null,
        createdAt: Date.now(),
      };
      commit([wish, ...wishesRef.current]);
      setMode({ kind: "view", id: wish.id });
      return;
    }
    if (mode.kind === "edit") {
      commit(
        wishesRef.current.map((wish) =>
          wish.id === mode.id ? { ...wish, title, note, image: draft.image } : wish,
        ),
      );
      setMode({ kind: "view", id: mode.id });
    }
  }

  function toggleDone(id: string) {
    commit(
      wishesRef.current.map((wish) => {
        if (wish.id !== id) return wish;
        const done = !wish.done;
        return { ...wish, done, doneAt: done ? Date.now() : null };
      }),
    );
  }

  function removeWish(id: string) {
    commit(wishesRef.current.filter((wish) => wish.id !== id));
    setMode({ kind: "idle" });
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) void takeFile(file);
  }

  const editing = mode.kind === "create" || mode.kind === "edit";
  const filters: { id: Filter; label: string }[] = [
    { id: "all", label: "Все" },
    { id: "open", label: "Ждут" },
    { id: "done", label: "Сбылись" },
  ];

  return (
    <main className="pad-fab mx-auto w-full max-w-5xl px-5 pt-10 sm:px-8 sm:pt-16">
      <header className="flex items-start justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-xs font-medium tracking-widest text-accent uppercase">
            <span className="inline-block h-px w-6 bg-accent" aria-hidden />
            для себя
          </p>
          <h1 className="mt-3 font-display text-5xl font-medium text-ink italic sm:text-6xl">Желания</h1>
          <p className="mt-3 text-sm text-muted tabular-nums" aria-live="polite">
            {ready ? listSummary(wishes) : "Тихий список для себя"}
          </p>
        </div>
        <button type="button" className={cn(btnPrimary, "mt-2 hidden sm:inline-flex")} onClick={openCreate}>
          <Plus className="size-4" aria-hidden />
          Новое
        </button>
      </header>

      {saveError ? (
        <p role="alert" className="mt-6 rounded-3xl bg-soft px-4 py-3 text-sm text-ink">
          {saveError}
        </p>
      ) : null}

      {wishes.length === 0 ? (
        <section className="mx-auto mt-20 max-w-md text-center sm:mt-28">
          <h2 className="font-display text-4xl font-medium text-ink italic sm:text-5xl">Пока здесь тихо</h2>
          <p className="mx-auto mt-4 max-w-sm text-muted">
            Добавьте желание и, если хотите, фотографию — чтобы помнить, как оно выглядит.
          </p>
        </section>
      ) : (
        <>
          <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <div role="group" aria-label="Фильтр" className="flex w-full rounded-full bg-soft p-1 sm:inline-flex sm:w-auto">
              {filters.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={filter === item.id}
                  onClick={() => setFilter(item.id)}
                  className={cn(
                    "h-11 flex-1 rounded-full px-4 text-sm transition-colors duration-150 ease-out sm:flex-none",
                    filter === item.id ? "bg-sheet text-ink" : "text-muted hover:text-ink",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="relative w-full sm:max-w-xs">
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Найти"
                aria-label="Найти желание"
                className="h-12 w-full border-b border-line bg-transparent pr-11 text-base text-ink outline-none placeholder:text-muted focus:border-accent"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Очистить поиск"
                  className="absolute top-0 right-0 flex h-12 w-11 items-center justify-center text-muted"
                >
                  <X className="size-4" aria-hidden />
                </button>
              ) : null}
            </div>
          </div>

          {visible.length === 0 ? (
            <p className="mt-16 text-center text-muted">
              {filter === "open" && !query.trim()
                ? "Всё, что ждало, уже сбылось."
                : "Ничего не нашлось."}
            </p>
          ) : (
            <ul className="mt-10 grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
              {visible.map((wish) => (
                <li key={wish.id} className="wish-rise">
                  <button
                    type="button"
                    onClick={() => setMode({ kind: "view", id: wish.id })}
                    className="group w-full text-left"
                  >
                    <div className="portrait relative overflow-hidden rounded-3xl bg-soft ring-1 ring-line">
                      {wish.image ? (
                        <img
                          src={wish.image}
                          alt=""
                          className={cn(
                            "wish-photo absolute inset-0 h-full w-full object-cover",
                            wish.done && "opacity-80 grayscale",
                          )}
                        />
                      ) : (
                        <span className="absolute inset-0 flex items-center justify-center font-display text-7xl font-medium text-accent/30 italic">
                          {monogram(wish.title)}
                        </span>
                      )}
                    </div>
                    <h2 className="mt-4 font-display text-2xl font-medium text-ink">{wish.title}</h2>
                    {wish.note ? <p className="mt-1 line-clamp-2 text-sm text-muted">{wish.note}</p> : null}
                    {wish.done ? (
                      <p className="mt-2 text-xs font-medium tracking-widest text-accent uppercase">Сбылось</p>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </>
      )}

      <p className="mt-16 text-center text-xs text-muted">Фото и список остаются только в этом браузере.</p>

      {mode.kind === "idle" ? (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper px-4 pt-3 pb-safe sm:hidden">
          <button type="button" className={cn(btnPrimary, "w-full")} onClick={openCreate}>
            <Plus className="size-4" aria-hidden />
            Новое желание
          </button>
        </div>
      ) : null}

      <Dialog.Root
        open={mode.kind !== "idle"}
        onOpenChange={(next) => {
          if (!next) setMode({ kind: "idle" });
        }}
      >
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
          <Dialog.Content className="fixed inset-0 z-50 overflow-y-auto overscroll-contain bg-paper outline-none">
            <div className="sticky top-0 z-10 flex items-center justify-between bg-paper px-2 py-2 sm:px-4">
              <button type="button" onClick={requestClose} className={btnGhost}>
                <ArrowLeft className="size-4" aria-hidden />
                Назад
              </button>
              {editing ? (
                <Dialog.Title className="pr-3 text-sm text-muted">
                  {mode.kind === "edit" ? "Изменить" : "Новое желание"}
                </Dialog.Title>
              ) : (
                <Dialog.Title className="sr-only">{active?.title ?? "Желание"}</Dialog.Title>
              )}
            </div>

            <Dialog.Description className="sr-only">
              {editing ? "Название, заметка и фотография желания." : "Карточка желания."}
            </Dialog.Description>

            {editing ? (
              <form onSubmit={saveDraft} className="mx-auto w-full max-w-xl px-5 pb-16 sm:px-8">
                <div
                  onDragOver={(event) => {
                    event.preventDefault();
                    setDragging(true);
                  }}
                  onDragLeave={(event) => {
                    if (event.currentTarget.contains(event.relatedTarget as Node | null)) return;
                    setDragging(false);
                  }}
                  onDrop={onDrop}
                  className={cn(
                    "relative overflow-hidden rounded-3xl bg-soft ring-1 ring-line",
                    dragging && "ring-2 ring-accent",
                  )}
                >
                  {draft.image ? (
                    <>
                      <img src={draft.image} alt="" className="h-80 w-full object-cover sm:h-96" />
                      <div className="absolute inset-x-0 bottom-0 flex gap-2 p-3">
                        <button type="button" onClick={() => fileRef.current?.click()} className={cn(btnLine, "bg-sheet/95")}>
                          Заменить
                        </button>
                        <button
                          type="button"
                          onClick={() => setDraft((current) => ({ ...current, image: null }))}
                          className={cn(btnLine, "bg-sheet/95")}
                        >
                          Убрать
                        </button>
                      </div>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileRef.current?.click()}
                      className="flex h-56 w-full flex-col items-center justify-center gap-2 px-6 text-center"
                    >
                      <ImagePlus className="size-6 text-accent" aria-hidden />
                      <span className="text-sm font-medium text-ink">Добавить фотографию</span>
                      <span className="text-xs text-muted">Выберите файл, перетащите или вставьте</span>
                    </button>
                  )}
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  aria-label="Фотография желания"
                  className="sr-only"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) void takeFile(file);
                  }}
                />
                <p className="mt-3 text-xs text-muted">
                  {busyPhoto ? "Готовлю фото…" : "Снимок сожмётся и останется только на этом устройстве."}
                </p>
                {photoError ? (
                  <p role="alert" className="mt-2 text-sm text-accent">
                    {photoError}
                  </p>
                ) : null}

                <label className="mt-8 block">
                  <span className="text-xs font-medium tracking-widest text-muted uppercase">Название</span>
                  <input
                    value={draft.title}
                    onChange={(event) => setDraft((current) => ({ ...current, title: event.target.value }))}
                    maxLength={80}
                    placeholder="Чего хочется"
                    className="mt-1 w-full border-b border-line bg-transparent py-3 font-display text-3xl text-ink outline-none placeholder:text-muted focus:border-accent"
                  />
                </label>
                <label className="mt-6 block">
                  <span className="text-xs font-medium tracking-widest text-muted uppercase">Заметка</span>
                  <textarea
                    value={draft.note}
                    onChange={(event) => setDraft((current) => ({ ...current, note: event.target.value }))}
                    maxLength={400}
                    rows={3}
                    placeholder="Зачем оно вам — если хочется записать"
                    className="mt-1 w-full resize-none border-b border-line bg-transparent py-3 text-base text-ink outline-none placeholder:text-muted focus:border-accent"
                  />
                </label>
                {formError ? (
                  <p role="alert" className="mt-4 text-sm text-accent">
                    {formError}
                  </p>
                ) : null}
                <div className="mt-8 flex flex-wrap gap-3">
                  <button type="submit" className={btnPrimary} disabled={busyPhoto}>
                    {mode.kind === "edit" ? "Сохранить" : "Добавить"}
                  </button>
                  <button type="button" className={btnGhost} onClick={requestClose}>
                    Отмена
                  </button>
                </div>
              </form>
            ) : null}

            {mode.kind === "view" && active ? (
              <article className="mx-auto w-full max-w-xl px-5 pb-16 sm:px-8">
                <div className="overflow-hidden rounded-3xl bg-soft ring-1 ring-line">
                  {active.image ? (
                    <img
                      src={active.image}
                      alt=""
                      className={cn("h-96 w-full object-cover sm:h-96", active.done && "grayscale")}
                    />
                  ) : (
                    <div className="flex h-56 items-center justify-center font-display text-7xl font-medium text-accent/30 italic">
                      {monogram(active.title)}
                    </div>
                  )}
                </div>
                <h2 className="mt-6 font-display text-4xl font-medium text-ink italic">{active.title}</h2>
                {active.note ? <p className="mt-3 text-base text-muted">{active.note}</p> : null}
                <p className="mt-4 text-sm text-muted">Добавлено {ruDate(active.createdAt)}</p>
                {active.done && active.doneAt ? (
                  <p className="mt-1 text-sm text-accent">Сбылось {ruDate(active.doneAt)}</p>
                ) : null}
                <div className="mt-8 flex flex-col gap-3">
                  <button type="button" className={cn(btnPrimary, "w-full")} onClick={() => toggleDone(active.id)}>
                    {active.done ? <Undo2 className="size-4" aria-hidden /> : <Check className="size-4" aria-hidden />}
                    {active.done ? "Вернуть в список" : "Отметить сбывшимся"}
                  </button>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      className={btnLine}
                      onClick={() => setMode({ kind: "edit", id: active.id })}
                    >
                      Изменить
                    </button>
                    {confirmDelete ? (
                      <button type="button" className={btnLine} onClick={() => setConfirmDelete(false)}>
                        Оставить
                      </button>
                    ) : (
                      <button type="button" className={btnGhost} onClick={() => setConfirmDelete(true)}>
                        Удалить
                      </button>
                    )}
                  </div>
                  {confirmDelete ? (
                    <button type="button" className={cn(btnPrimary, "w-full")} onClick={() => removeWish(active.id)}>
                      Удалить навсегда
                    </button>
                  ) : null}
                </div>
              </article>
            ) : null}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </main>
  );
}
