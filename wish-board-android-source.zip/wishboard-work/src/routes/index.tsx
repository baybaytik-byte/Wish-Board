import { createFileRoute } from "@tanstack/react-router";
import { WishBoard } from "@/components/wish-board";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <WishBoard />;
}
